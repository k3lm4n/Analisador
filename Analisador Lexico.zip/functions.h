typedef struct tab tabela;
typedef struct elem Elem;


void add(tabela *Table, Elem lex);
void criar(tabela *Table);