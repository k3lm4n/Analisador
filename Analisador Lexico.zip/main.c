#include <stdio.h>
#include <stdlib.h>
#include "functions.c"
#include "functions.h"
#include <string.h>

int main()
{
    tabela *LexTable;
    analex(0,LexTable);
}
